// ==========================================================
// TEMPLE RUN DEMO - 3D Perspective Endless Runner (PREMIUM)
// ==========================================================
// Fixed: Joystick Edge Detection (Menu Beep Fix)
// Features: 5s Magnet, Pixel Cat, Difficulty Select, Y-Offset
// Modified: Blue Coins
// ==========================================================

#include "main.h"
#include "tim.h"       
#include "usart.h"     
#include "gpio.h"      
#include "adc.h"       
#include "rng.h"       

#include "Buzzer.h" 
#include "PWM.h"    
#include "LCD.h"  
#include "Joystick.h" 
#include "Utils.h" 

#include <stdint.h>
#include <stdio.h>
#include <math.h>

extern RNG_HandleTypeDef hrng;

void SystemClock_Config(void);
void PeriphCommonClock_Config(void);

// ===== 硬件配置 =====
Buzzer_cfg_t buzzer_cfg = {
    .htim = &htim2, .channel = TIM_CHANNEL_3,
    .tick_freq_hz = 1000000, .min_freq_hz = 20, .max_freq_hz = 20000, .setup_done = 0
};

ST7789V2_cfg_t cfg0 = {
    .setup_done = 0, .spi = SPI2,
    .RST = {.port = GPIOB, .pin = GPIO_PIN_2},
    .BL = {.port = GPIOB, .pin = GPIO_PIN_1},
    .DC = {.port = GPIOB, .pin = GPIO_PIN_11},
    .CS = {.port = GPIOB, .pin = GPIO_PIN_12},
    .MOSI = {.port = GPIOB, .pin = GPIO_PIN_15},
    .SCLK = {.port = GPIOB, .pin = GPIO_PIN_13},
    .dma = {.instance = DMA1, .channel = DMA1_Channel5}
};

Joystick_cfg_t joystick_cfg = {
    .adc = &hadc1, .x_channel = ADC_CHANNEL_1, .y_channel = ADC_CHANNEL_2, 
    .sampling_time = ADC_SAMPLETIME_47CYCLES_5,
    .center_x = JOYSTICK_DEFAULT_CENTER_X, .center_y = JOYSTICK_DEFAULT_CENTER_Y,
    .deadzone = JOYSTICK_DEADZONE, .setup_done = 0
};

PWM_cfg_t led_pwm_cfg = {
    .htim = &htim4, .channel = TIM_CHANNEL_1,
    .tick_freq_hz = 1000000, .min_freq_hz = 10, .max_freq_hz = 50000, .setup_done = 0
};

Joystick_t joystick_data;

int _write(int file, char *ptr, int len) {
    HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}


void Manual_Hardware_Init(void) {
    __HAL_RCC_GPIOC_CLK_ENABLE(); 
    __HAL_RCC_GPIOB_CLK_ENABLE(); 

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT; 
    GPIO_InitStruct.Pull = GPIO_PULLUP;          
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;      
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM4;   
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

// ===== 游戏逻辑与 3D 数学结构 =====
#define SCREEN_W 240
#define SCREEN_H 280
#define FPS 30
#define FRAME_TIME_MS (1000 / FPS)

#define HORIZON_Y 100
#define BOTTOM_Y 260
#define LANE_OFFSET_MAX 80 
#define MAX_ITEMS 3 

#define MAGNET_DURATION_FRAMES (5 * FPS) 
#define MOUNT_DURATION_FRAMES (10 * FPS)  

// 猫猫 Y 轴偏移量：保持与屏幕底部的距离
#define PLAYER_Y_OFFSET 25 

typedef enum { 
    STATE_MENU, 
    STATE_RUNNING, 
    STATE_PAUSED,  
    STATE_GAMEOVER 
} GameState;

typedef struct {
    int lane;           
    float jump_y;       
    float vy;           
    uint8_t is_sliding; 
    uint8_t has_shield; 
    int magnet_timer;   
    int mount_timer;    
} Player3D;

typedef struct { int lane; float z; int type; uint8_t active; } Obstacle3D;
typedef struct { int lane; float z; int type; uint8_t active; } Item3D; 
typedef struct { int lane; float z; uint8_t active; } Animal3D;

// 全局变量
GameState current_state = STATE_MENU;
Player3D player;
Obstacle3D obstacle;
Item3D items[MAX_ITEMS]; 
Animal3D animal;

uint32_t score = 0;
float global_speed = 3.0f;
float speed_increment = 0.02f;
int selected_difficulty = 1; // 0: EASY, 1: NORMAL, 2: HARD

uint32_t last_jump_time = 0; 
uint32_t last_lane_time = 0; 
uint8_t last_btn_state = 1;
uint8_t joy_y_handled = 0; // 用于菜单摇杆边缘检测

void Reset_Game() {
    player.lane = 0; player.jump_y = 0; player.vy = 0; 
    player.is_sliding = 0; player.has_shield = 0;
    player.magnet_timer = 0; player.mount_timer = 0;

    obstacle.lane = 0; obstacle.z = 100.0f; obstacle.type = 0; obstacle.active = 1;
    for(int i=0; i<MAX_ITEMS; i++) items[i].active = 0;
    
    animal.active = 0; animal.z = 100.0f;
    score = 0; 
    PWM_SetDuty(&led_pwm_cfg, 0); 
    
    if (selected_difficulty == 0) { // EASY
        global_speed = 2.0f; speed_increment = 0.01f;
    } else if (selected_difficulty == 1) { // NORMAL
        global_speed = 3.0f; speed_increment = 0.02f;
    } else { // HARD
        global_speed = 4.5f; speed_increment = 0.035f;
    }
}

void Draw3DObject(int lane, float z, uint16_t color, int obj_type, float jump_y) {
    if (z < 0 || z > 100) return; 
    float scale = (100.0f - z) / 100.0f; 
    if (scale < 0.05f) return; 

    int screen_y = HORIZON_Y + (int)((BOTTOM_Y - HORIZON_Y) * scale);
    int screen_x = 120 + (int)(lane * LANE_OFFSET_MAX * scale);
    int w, h, draw_y;
    
    if (obj_type == 1) { // 横梁
        w = (int)(60 * scale); h = (int)(15 * scale); 
        draw_y = screen_y - h - (int)(40 * scale) + (int)(jump_y * scale) - PLAYER_Y_OFFSET; 
    } 
    else if (obj_type == 0) { // 地刺
        w = (int)(40 * scale); h = (int)(40 * scale);
        draw_y = screen_y - h + (int)(jump_y * scale) - PLAYER_Y_OFFSET;
    }
    else if (obj_type == 2) { // 金币 
        w = (int)(20 * scale); h = (int)(20 * scale);
        draw_y = screen_y - h - (int)(20 * scale) + (int)(jump_y * scale) - PLAYER_Y_OFFSET;
    }
    else if (obj_type == 3) { // 护盾
        w = (int)(25 * scale); h = (int)(25 * scale);
        draw_y = screen_y - h - (int)(20 * scale) + (int)(jump_y * scale) - PLAYER_Y_OFFSET;
    }
    else if (obj_type == 4) { // 磁铁
        w = (int)(10 * scale); h = (int)(10 * scale); 
        draw_y = screen_y - h - (int)(25 * scale) + (int)(jump_y * scale) - PLAYER_Y_OFFSET; 
    }
    else if (obj_type == 5) { // 动物 
        w = (int)(35 * scale); h = (int)(30 * scale);
        draw_y = screen_y - h + (int)(jump_y * scale) - PLAYER_Y_OFFSET;
    }
    
    LCD_Draw_Rect(screen_x - w/2, draw_y, w, h, color, 1);
    if (obj_type != 4) LCD_Draw_Line(screen_x - w/2, draw_y, screen_x + w/2, draw_y, LCD_COLOUR_15); 
}

// ===== 主循环 =====
int main(void)
{
    HAL_Init(); SystemClock_Config(); PeriphCommonClock_Config();
    MX_GPIO_Init(); Manual_Hardware_Init(); MX_USART2_UART_Init();
    MX_ADC1_Init(); MX_RNG_Init();   
    LCD_init(&cfg0); MX_TIM2_Init(); buzzer_init(&buzzer_cfg);
    MX_TIM4_Init(); PWM_Init(&led_pwm_cfg); PWM_SetFreq(&led_pwm_cfg, 1000);
    Joystick_Init(&joystick_cfg);
    
    Reset_Game();
    uint32_t last_tick = HAL_GetTick();

    while (1)
    {
        uint32_t now = HAL_GetTick();
        if ((now - last_tick) < FRAME_TIME_MS) continue; 
        last_tick = now;

        Joystick_Read(&joystick_cfg, &joystick_data);
        
        // 统一按钮边缘检测逻辑 (PC3)
        uint8_t btn_state = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_3);
        uint8_t btn_pressed = (btn_state == 0 && last_btn_state == 1);
        last_btn_state = btn_state;

        // 音效自动截止逻辑
        if(now - last_jump_time > 150) buzzer_off(&buzzer_cfg); 

        LCD_Fill_Buffer(LCD_COLOUR_0); 

        if (current_state == STATE_MENU) {
            LCD_Draw_Line(20, 40, 220, 40, LCD_COLOUR_14);
            LCD_printString("TEMPLE RUN", 20, 50, LCD_COLOUR_14, 3);
            LCD_Draw_Line(20, 85, 220, 85, LCD_COLOUR_14);
            LCD_printString("- SELECT DIFF -", 30, 100, LCD_COLOUR_3, 2);

            // 摇杆边缘检测逻辑：防止连响
            if (fabs(joystick_data.coord_mapped.y) < 0.2f) {
                joy_y_handled = 0; 
            } else if (!joy_y_handled) {
                if (joystick_data.coord_mapped.y > 0.5f) { // 向上
                    selected_difficulty = (selected_difficulty == 0) ? 0 : selected_difficulty - 1;
                    joy_y_handled = 1; last_jump_time = now; 
                    buzzer_tone(&buzzer_cfg, 1500, 50);
                } else if (joystick_data.coord_mapped.y < -0.5f) { // 向下
                    selected_difficulty = (selected_difficulty == 2) ? 2 : selected_difficulty + 1;
                    joy_y_handled = 1; last_jump_time = now;
                    buzzer_tone(&buzzer_cfg, 1500, 50);
                }
            }

            // 渲染菜单
            uint16_t c_easy = (selected_difficulty == 0) ? LCD_COLOUR_1 : LCD_COLOUR_13;
            uint16_t c_norm = (selected_difficulty == 1) ? LCD_COLOUR_1 : LCD_COLOUR_13;
            uint16_t c_hard = (selected_difficulty == 2) ? LCD_COLOUR_1 : LCD_COLOUR_13;

            LCD_printString(selected_difficulty == 0 ? "> EASY <" : "  EASY  ", 56, 140, c_easy, 2);
            LCD_printString(selected_difficulty == 1 ? "> NORMAL <" : "  NORMAL  ", 40, 170, c_norm, 2);
            LCD_printString(selected_difficulty == 2 ? "> HARD <" : "  HARD  ", 56, 200, c_hard, 2);
            
            if ((now / 500) % 2 == 0) LCD_printString("BTN TO START", 24, 240, LCD_COLOUR_5, 2);
            
            if (btn_pressed) {
                Reset_Game(); current_state = STATE_RUNNING; 
                last_jump_time = now; buzzer_tone(&buzzer_cfg, 2500, 100);
            }
        } 
        else if (current_state == STATE_PAUSED) {
            LCD_printString("PAUSED", 60, 120, LCD_COLOUR_14, 3);
            if ((now / 500) % 2 == 0) LCD_printString("CLICK BTN TO RESUME", 15, 170, LCD_COLOUR_3, 1);
            if (btn_pressed) {
                current_state = STATE_RUNNING;
                last_jump_time = now; buzzer_tone(&buzzer_cfg, 2000, 100);
            }
        }
        else if (current_state == STATE_RUNNING) {
            if (btn_pressed) {
                current_state = STATE_PAUSED;
                last_jump_time = now; buzzer_tone(&buzzer_cfg, 1000, 100);
            }

            // 道具逻辑更新
            if (player.magnet_timer > 0) {
                player.magnet_timer--;
                if (player.magnet_timer < 90 && (player.magnet_timer % 15 == 0)) buzzer_tone(&buzzer_cfg, 4000, 30); 
            }
            if (player.mount_timer > 0) {
                player.mount_timer--; score += 1; 
                if (player.mount_timer < 90 && (player.mount_timer % 15 == 0)) buzzer_tone(&buzzer_cfg, 3500, 30); 
            }

            // 1. 玩家控制
            if (now - last_lane_time > 150) {
                if (joystick_data.coord_mapped.x < -0.5f && player.lane > -1) { player.lane--; last_lane_time = now; } 
                else if (joystick_data.coord_mapped.x > 0.5f && player.lane < 1) { player.lane++; last_lane_time = now; }
            }

            if (joystick_data.coord_mapped.y > 0.5f) { 
                if (player.jump_y >= 0.0f && !player.is_sliding && now - last_jump_time > 200) {
                    player.vy = -12.0f; last_jump_time = now; buzzer_tone(&buzzer_cfg, 1200, 50); 
                }
            }
            else if (joystick_data.coord_mapped.y < -0.5f && player.jump_y >= 0.0f) player.is_sliding = 1;
            else player.is_sliding = 0;

            player.vy += 1.5f; player.jump_y += player.vy;
            if (player.jump_y >= 0.0f) { player.jump_y = 0.0f; player.vy = 0; }

            // 2. 实体更新
            uint32_t rand_val;
            obstacle.z -= global_speed;
            if (obstacle.z < -10.0f) {
                obstacle.z = 100.0f; score += 10; global_speed += speed_increment;
                HAL_RNG_GenerateRandomNumber(&hrng, &rand_val);
                obstacle.lane = (rand_val % 3) - 1; obstacle.type = (rand_val >> 4) % 2; obstacle.active = 1;
            }

            for(int i=0; i<MAX_ITEMS; i++) {
                if(items[i].active) {
                    items[i].z -= global_speed;
                    if (player.magnet_timer > 0 && items[i].type == 0 && items[i].z < 60.0f && items[i].z > 10.0f) items[i].lane = player.lane; 
                    if (items[i].z < -10.0f) items[i].active = 0; 
                } else {
                    HAL_RNG_GenerateRandomNumber(&hrng, &rand_val);
                    if (rand_val % 100 < 5) { 
                        items[i].active = 1; items[i].z = 100.0f + (rand_val % 30); items[i].lane = (rand_val % 3) - 1;
                        int r = (rand_val >> 3) % 100;
                        if (r < 70) items[i].type = 0;      
                        else if (r < 85) items[i].type = 1; 
                        else items[i].type = (score >= 250) ? 2 : 0;
                    }
                }
            }

            // 3. 碰撞检测
            if (animal.active && animal.z < 5.0f && animal.z > -5.0f && animal.lane == player.lane) {
                if (player.jump_y > -30.0f) { animal.active = 0; player.mount_timer = MOUNT_DURATION_FRAMES; buzzer_tone(&buzzer_cfg, 3000, 100); }
            }

            for(int i=0; i<MAX_ITEMS; i++) {
                if (items[i].active && items[i].z < 5.0f && items[i].z > -5.0f && items[i].lane == player.lane) {
                    if (player.jump_y > -40.0f) { 
                        items[i].active = 0; 
                        if (items[i].type == 0) { score += 50; buzzer_tone(&buzzer_cfg, 1500, 50); } 
                        else if (items[i].type == 1) { player.has_shield = 1; PWM_SetDuty(&led_pwm_cfg, 20); buzzer_tone(&buzzer_cfg, 2000, 50); } 
                        else if (items[i].type == 2) { player.magnet_timer = MAGNET_DURATION_FRAMES; buzzer_tone(&buzzer_cfg, 2500, 80); }
                    }
                }
            }

            if (obstacle.active && obstacle.z < 5.0f && obstacle.z > -5.0f && obstacle.lane == player.lane) {
                uint8_t hit = (obstacle.type == 0 && player.jump_y > -30.0f) || (obstacle.type == 1 && !player.is_sliding);
                if (hit) {
                    if (player.mount_timer > 0) { obstacle.active = 0; score += 100; buzzer_tone(&buzzer_cfg, 500, 50); }
                    else if (player.has_shield) { player.has_shield = 0; obstacle.active = 0; PWM_SetDuty(&led_pwm_cfg, 0); buzzer_tone(&buzzer_cfg, 800, 50); last_jump_time = now; } 
                    else { current_state = STATE_GAMEOVER; PWM_SetDuty(&led_pwm_cfg, 100); buzzer_tone(&buzzer_cfg, 200, 200); }
                }
            }

            // 4. 画面渲染
            LCD_Draw_Line(0, HORIZON_Y, SCREEN_W, HORIZON_Y, LCD_COLOUR_13);
            LCD_Draw_Line(120, HORIZON_Y, 120 - LANE_OFFSET_MAX - 20, BOTTOM_Y, LCD_COLOUR_13); 
            LCD_Draw_Line(120, HORIZON_Y, 120 + LANE_OFFSET_MAX + 20, BOTTOM_Y, LCD_COLOUR_13); 

            if(obstacle.active) Draw3DObject(obstacle.lane, obstacle.z, (obstacle.type == 0) ? LCD_COLOUR_2 : LCD_COLOUR_1, obstacle.type, 0);
            
            // [修改] 金币颜色变更逻辑
            for(int i=0; i<MAX_ITEMS; i++) {
                if(items[i].active) {
                    uint16_t color;
                    if(items[i].type == 0) color = LCD_COLOUR_4;       // [修改] 金币变更为蓝色 (LCD_COLOUR_4)
                    else if(items[i].type == 1) color = LCD_COLOUR_5;  // 护盾保持青色
                    else color = LCD_COLOUR_1;                         // 磁铁保持红色
                    Draw3DObject(items[i].lane, items[i].z, color, items[i].type + 2, 0);
                }
            }

            // 渲染猫猫
            int px = 120 + player.lane * LANE_OFFSET_MAX - 20;
            int py = BOTTOM_Y - 40 - PLAYER_Y_OFFSET + (int)player.jump_y; 
            uint16_t player_color = player.mount_timer > 0 ? LCD_COLOUR_6 : (player.has_shield ? LCD_COLOUR_5 : LCD_COLOUR_3);

            if (player.is_sliding) {
                LCD_Draw_Rect(px + 5, py + 30, 30, 10, player_color, 1); LCD_Draw_Rect(px + 25, py + 25, 12, 12, player_color, 1); 
            } else {
                LCD_Draw_Rect(px + 10, py + 15, 20, 25, player_color, 1); LCD_Draw_Rect(px + 5, py, 30, 20, player_color, 1);     
                LCD_Draw_Rect(px + 5, py - 5, 8, 8, player_color, 1); LCD_Draw_Rect(px + 27, py - 5, 8, 8, player_color, 1);    
            }

            char ui_str[32];
            sprintf(ui_str, "Score: %lu", (unsigned long)score); LCD_printString(ui_str, 5, 5, LCD_COLOUR_1, 1);
            if (player.magnet_timer > 0) { sprintf(ui_str, "MAG: %ds", (player.magnet_timer / FPS) + 1); LCD_printString(ui_str, 5, 35, LCD_COLOUR_14, 1); }
        } 
        else if (current_state == STATE_GAMEOVER) {
            LCD_printString("GAME OVER", 35, 80, LCD_COLOUR_2, 3);
            if ((now / 500) % 2 == 0) LCD_printString("BTN TO RESTART", 8, 210, LCD_COLOUR_13, 2);
            if (btn_pressed && now - last_jump_time > 1000) { current_state = STATE_MENU; last_jump_time = now; }
        }
        LCD_Refresh(&cfg0);
    }
}

// ==== 时钟配置函数 (略) ====
void SystemClock_Config(void) { /* ... */ }
void PeriphCommonClock_Config(void) { /* ... */ }
void Error_Handler(void) { __disable_irq(); while (1); }